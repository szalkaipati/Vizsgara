import { Routes } from '@angular/router';
import { NyitooldalComponent } from './nyitooldal/nyitooldal.component';
import { AllatainkComponent } from './allataink/allataink.component';
import { UjAllatComponent } from './uj-allat/uj-allat.component';

export const routes: Routes = [
    {
        path: '',
        component: NyitooldalComponent
    },
    {
        path: 'allataink',
        component: AllatainkComponent
    },
    {
        path: 'ujallat',
        component: UjAllatComponent
    }
];
