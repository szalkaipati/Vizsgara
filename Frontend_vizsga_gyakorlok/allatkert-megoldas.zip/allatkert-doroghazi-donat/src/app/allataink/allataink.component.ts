import { HttpClient } from '@angular/common/http';
import { Component, DestroyRef, inject, OnInit, signal } from '@angular/core';

interface Allat {
  nev: string;
  faj: string;
  erkezes: Date;
  helye: string;
  gondozo: string;
}

@Component({
  selector: 'app-allataink',
  imports: [],
  templateUrl: './allataink.component.html',
  styleUrl: './allataink.component.css',
})
export class AllatainkComponent implements OnInit {
  httpClient = inject(HttpClient);
  destroyRef = inject(DestroyRef);
  allatok = signal<Allat[]>([]);
  error = signal<string | null>(null);

  ngOnInit(): void {
    const subscription = this.httpClient
      .get<Allat[]>('http://localhost:5000/allatok')
      .subscribe({
        next: data =>{
          // console.log(data);
          const rendezett = data.sort( (x, y) => x.gondozo > y.gondozo? 1 : -1 );
          this.allatok.set(rendezett);
        },
        error: error =>{
          this.error.set(error.message);
        }
      });

    this.destroyRef.onDestroy(() => subscription.unsubscribe());
  }
}
