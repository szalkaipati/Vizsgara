import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-nyitooldal',
  imports: [RouterLink],
  templateUrl: './nyitooldal.component.html',
  styleUrl: './nyitooldal.component.css'
})
export class NyitooldalComponent {

}
