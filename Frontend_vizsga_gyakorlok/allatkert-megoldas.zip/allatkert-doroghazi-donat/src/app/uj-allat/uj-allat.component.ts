import { HttpClient } from '@angular/common/http';
import { Component, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

interface Gondozo {
  nev: string;
}

@Component({
  selector: 'app-uj-allat',
  imports: [FormsModule],
  templateUrl: './uj-allat.component.html',
  styleUrl: './uj-allat.component.css',
})
export class UjAllatComponent implements OnInit {
  httpClient = inject(HttpClient);
  destroyRef = inject(DestroyRef);
  router = inject(Router);
  gondozok = signal<Gondozo[]>([]);
  error = signal<string | null>(null);

  formModel = {
    nev: '',
    faj: '',
    erkezes: new Date().toISOString().substring(0, 10),
    helye: '',
    gondozo: 'Kérem válasszon',
  };

  ngOnInit(): void {
    const subscription = this.httpClient
      .get<Gondozo[]>('http://localhost:5000/gondozok')
      .subscribe({
        next: (data) => {
          this.gondozok.set(data);
        },
        error: (error) => {
          this.error.set(error.message);
        },
      });

    this.destroyRef.onDestroy(() => subscription.unsubscribe());
  }

  onHandlingForm(){
    return (
      this.formModel.nev == '' ||
      this.formModel.faj == '' ||
      this.formModel.helye == '' ||
      this.formModel.gondozo === 'Kérem válasszon'
    );
  }

  onSubmit() {
    // console.log(this.formModel);
    if (this.onHandlingForm()) {
      this.error.set("Kötelező kitölteni minden mezőt és gondozót választani is!");
      return;
    }

    if(this.formModel.nev.length < 3){
      this.error.set("Az állat neve nem elég hosszú. Legalább 3 karakter legyen!");
      return;
    }

    const subscription = this.httpClient
      .post('http://localhost:5000/ujallat', this.formModel)
      .subscribe({
        next: (data) => {
          console.log(data);
        },
        error: (error) => {
          if (error.status == 201) this.router.navigate(['/allataink']);
          else this.error.set(error.message);
        },
      });

    this.destroyRef.onDestroy(() => subscription.unsubscribe());
  }
}
