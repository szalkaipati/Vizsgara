import { Routes } from '@angular/router';
import { NyitooldalComponent } from './nyitooldal/nyitooldal.component';
import { HirdetesekComponent } from './hirdetesek/hirdetesek.component';
import { UjHirdetesComponent } from './uj-hirdetes/uj-hirdetes.component';

export const routes: Routes = [
    {
        path: '',
        component: NyitooldalComponent
    },
    {
        path: 'offers',
        component: HirdetesekComponent
    },
    {
        path: 'newad',
        component: UjHirdetesComponent
    }
];
