import { HttpClient } from '@angular/common/http';
import { Component, DestroyRef, inject, OnInit, signal } from '@angular/core';

interface Ingatlan {
  id: number;
  kategoriaId: number;
  kategoriaNev: string;
  leiras: string;
  hirdetesDatuma: Date;
  tehermentes: boolean;
  kepUrl: string;
}

@Component({
  selector: 'app-hirdetesek',
  imports: [],
  templateUrl: './hirdetesek.component.html',
  styleUrl: './hirdetesek.component.css',
})
export class HirdetesekComponent implements OnInit {
  httpClient = inject(HttpClient);
  destroyRef = inject(DestroyRef);
  hirdetesek = signal<Ingatlan[]>([]);
  errorData = signal(null);

  ngOnInit(): void {
    const subscripton = this.httpClient
      .get<Ingatlan[]>('http://localhost:5000/api/ingatlan')      
      .subscribe({
        next: data =>{
          // console.log(data);
          this.hirdetesek.set(data);
          // console.log(this.hirdetesek());
        },
        error: err =>{
          this.errorData.set(err);
        }
      });

    this.destroyRef.onDestroy(() => subscripton.unsubscribe());
  }
}
