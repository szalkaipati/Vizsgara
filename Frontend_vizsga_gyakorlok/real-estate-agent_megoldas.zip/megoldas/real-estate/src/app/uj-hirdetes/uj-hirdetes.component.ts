import { HttpClient } from '@angular/common/http';
import { Component, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

interface Kategoria {
  id: number;
  megnevezes: string;
}

@Component({
  selector: 'app-uj-hirdetes',
  imports: [ReactiveFormsModule],
  templateUrl: './uj-hirdetes.component.html',
  styleUrl: './uj-hirdetes.component.css',
})
export class UjHirdetesComponent implements OnInit {
  httpClient = inject(HttpClient);
  destroyRef = inject(DestroyRef);
  router = inject(Router);

  kategoriak = signal<Kategoria[]>([]);
  errorMessage = signal<string | null>(null);

  myForm = new FormGroup({
    kategoria: new FormControl('0'),
    datum: new FormControl(new Date().toISOString().slice(0, 10)),
    leiras: new FormControl('', {
      validators: [Validators.required]
    }),
    tehermentes: new FormControl(true),
    kepUrl: new FormControl(''),
  });

  ngOnInit(): void {
    const subscription = this.httpClient
      .get<Kategoria[]>('http://localhost:5000/api/kategoriak')
      .subscribe({
        next: (data) => {
          // console.log(data);
          this.kategoriak.set(data);
        },
        error: (err) => {},
      });

    this.destroyRef.onDestroy(() => subscription.unsubscribe());
  }

  onSubmit() {
    //console.log(this.myForm);
    if (this.myForm.invalid) {      
      this.errorMessage.set('Valamelyik beviteli mező hibás!');

      if(this.myForm.controls.leiras.invalid)
        this.errorMessage.set("Nem lehet üres a leírás mező!");

      if(this.myForm.controls.kategoria.value == '0' )
        this.errorMessage.set('Kategóriát mindenképpen választani kell!');

      return;
    }

    const ujHirdetes = {      
      kategoriaId: Number(this.myForm.controls.kategoria.value),
      leiras: this.myForm.controls.leiras.value,
      hirdetesDatuma: this.myForm.controls.datum.value,
      tehermentes: this.myForm.controls.tehermentes.value,
      kepUrl: this.myForm.controls.kepUrl.value,
    };

    const subscription = this.httpClient
      .post('http://localhost:5000/api/ujingatlan', ujHirdetes)
      .subscribe({
        next: data =>{
          // console.log(data);
          this.router.navigate(['/offers']);
        },
        error: err =>{          
          this.errorMessage.set(err.message);
        }
      });

    this.destroyRef.onDestroy(() => subscription.unsubscribe());

  }
}
