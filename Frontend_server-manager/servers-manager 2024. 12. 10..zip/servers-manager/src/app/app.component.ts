import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { ServerStatusComponent } from './dashboard/server-status/server-status.component';
import { TrafficComponent } from './dashboard/traffic/traffic.component';
import { TicketsComponent } from './dashboard/tickets/tickets.component';
import { DashboardItemComponent } from './dashboard/dashboard-item/dashboard-item.component';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  imports: [
    HeaderComponent,
    ServerStatusComponent,
    TrafficComponent,
    TicketsComponent,
    DashboardItemComponent,
  ],
})
export class AppComponent implements OnInit {
  tmp: string = 'Ez egy szöveg';

  ngOnInit(): void {
    setInterval(() => {
      const r = Math.random();

      if (r < 0.3) this.tmp = 'egy';
      else if (r < 0.6) this.tmp = 'kettő';
      else if (r < 0.8) this.tmp = 'hat';
      else this.tmp = 'nyóc';
    }, 20000);
  }
}
