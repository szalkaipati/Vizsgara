import {
  Component,
  input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from '@angular/core';
import { interval } from 'rxjs';

@Component({
  selector: 'app-server-status',
  standalone: true,
  imports: [],
  templateUrl: './server-status.component.html',
  styleUrl: './server-status.component.css',
})
export class ServerStatusComponent implements OnInit, OnChanges, OnDestroy {
  currentStatus: 'online' | 'offline' | 'unknown' = 'online';
  myInterval?: ReturnType<typeof setInterval>;  
  valtozo = input.required<string>();

  constructor() {}

  ngOnInit() {
    console.log('Meghívódott az ngOnInit!');

    this.myInterval = setInterval(() => {
      const rnd = Math.random();

      if (rnd < 0.5) this.currentStatus = 'online';
      else if (rnd < 0.9) this.currentStatus = 'offline';
      else this.currentStatus = 'unknown';
    }, 3000);
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('Valami megáltozott...');
    console.log(changes);
  }

  ngOnDestroy(): void {
    clearInterval(this.myInterval);
  }

  get statusCSS() {
    if (this.currentStatus === 'online') return 'status status-online';
    else if (this.currentStatus === 'offline') return 'status status-offline';
    else return 'status status-unkonwn';
  }
}

/*
export class ServerStatusComponent implements OnInit, OnChanges, DoCheck {
  currentStatus: 'online' | 'offline' | 'unknown' = 'online';

  constructor(){}

  ngOnInit(){
    console.log("Meghívódott az ngOnInit!");

    setInterval(() => {
      const rnd = Math.random();

      if(rnd < 0.5)
        this.currentStatus = "online";
      else if(rnd < 0.9)
        this.currentStatus = "offline";
      else
        this.currentStatus = "unknown";

    }, 3000);
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log("Meghívódott az ngOnChanges");
  }

  ngDoCheck(): void {
    console.log("Meghívódott az ngDoCheck!");
  }

  get statusCSS(){
    if( this.currentStatus === 'online' )
      return "status status-online";
    else if( this.currentStatus === 'offline' )
      return "status status-offline";
    else
      return "status status-unkonwn";
  }
}


*/
