import { Component } from '@angular/core';
import { MybuttonComponent } from "../../../shared/mybutton/mybutton.component";
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-new-ticket',
  standalone: true,
  imports: [MybuttonComponent, FormsModule],
  templateUrl: './new-ticket.component.html',
  styleUrl: './new-ticket.component.css'
})
export class NewTicketComponent {

  formSubmit(titleText: string, requestText: string){
    // console.dir(titleText);
    console.log(titleText);
    console.log(requestText); 
  }
}
