import { Component } from '@angular/core';

@Component({
  selector: 'button[myButton]',
  standalone: true,
  imports: [],
  templateUrl: './mybutton.component.html',
  styleUrl: './mybutton.component.css'
})
export class MybuttonComponent {

}
