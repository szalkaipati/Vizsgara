import { Component } from '@angular/core';
import { DUMMY_USERS } from '../../dummy_users';

const dummy_user = DUMMY_USERS[Math.floor(Math.random()*DUMMY_USERS.length)];

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [],
  templateUrl: './app-user.component.html',
  styleUrl: './app-user.component.css'
})
export class AppUserComponent {
    user = dummy_user;

    get pictureUrl(){
      return 'assets/users/' + this.user.pic;
    }
}
