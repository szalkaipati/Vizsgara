import { Component } from '@angular/core';
import { DUMMY_USERS } from './app-users/dummy_users';
import { IUser } from './app-users/user.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  selectedUserId?: number;
  user?: IUser;

  onSelect(id: number){
    this.selectedUserId = id;    
    this.userName();
  }  

  userName(){
    if( this.selectedUserId === undefined )
      return;

    for(let i=0; i<DUMMY_USERS.length; i++)
      if( DUMMY_USERS[i].id === this.selectedUserId)
        this.user = DUMMY_USERS[i];

    return;
  }
}
