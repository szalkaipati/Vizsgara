import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IUser } from '../user.model';

@Component({
  selector: 'app-user',
  templateUrl: './app-user.component.html',
  styleUrl: './app-user.component.css'
})
export class AppUserComponent {
    @Input({ required: true }) user!: IUser;  
    @Input({ required: true }) selectedUser!: boolean;
    @Output() select = new EventEmitter();

    get pictureUrl(){
      return 'assets/users/' + this.user.pic;
    }

    onSelect(){
      this.select.emit(this.user.id);
    }

    get isActive(): string{
      return this.selectedUser?'active':'';
    }

}
