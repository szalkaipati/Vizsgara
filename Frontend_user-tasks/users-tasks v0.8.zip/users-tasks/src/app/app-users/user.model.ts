export interface IUser{
    id: number,
    name: string,
    pic: string
  }