import { Injectable } from "@angular/core";
import { DUMMY_USERS } from "./dummy_users";

@Injectable({ providedIn: 'root'})
export class UsersService{
    private users = DUMMY_USERS;

    get allUser(){ return this.users; }
}