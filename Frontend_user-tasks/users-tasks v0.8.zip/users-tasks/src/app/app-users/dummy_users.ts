export const DUMMY_USERS =[
    {
        id: 0,
        name: 'Maximilian Taylor',
        pic: 'user1.jpg'
    },
    {
        id: 1,
        name: 'Jack Smith',
        pic: 'user2.jpg'
    },
    {
        id: 2,
        name: 'Susan Black',
        pic: 'user3.jpg'
    },
    {
        id: 3,
        name: 'Peter Bishop',
        pic: 'user4.jpg'
    },
    {
        id: 4,
        name: 'Barbara Lake',
        pic: 'user5.jpg'
    },
    {
        id: 5,
        name: 'Samanta White',
        pic: 'user6.jpg'
    }
];