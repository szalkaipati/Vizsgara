import { NgModule } from "@angular/core";
import { AppUsersComponent } from "./app-users.component";
import { AppUserComponent } from "./app-user/app-user.component";
import { UsersService } from "./users.service";
import { SharedStyleComponent } from "../shared-style/shared-style.component";


@NgModule({
    declarations: [AppUsersComponent, AppUserComponent, SharedStyleComponent],
    imports: [],
    exports: [AppUsersComponent, AppUserComponent, SharedStyleComponent],
    providers: [UsersService]
})
export class UsersModule{

}