import { Component, EventEmitter, inject, Output } from '@angular/core';
import { UsersService } from './users.service';

@Component({
  selector: 'app-users',
  templateUrl: './app-users.component.html',
  styleUrl: './app-users.component.css'
})
export class AppUsersComponent {
  selectedId?: number;
  @Output() select = new EventEmitter();
  userService: UsersService = inject(UsersService);

  onSelect(id: number){
    this.selectedId = id;
    this.select.emit(id);
  }

  isSelected(id: number){
    return id===this.selectedId;
  }
}
