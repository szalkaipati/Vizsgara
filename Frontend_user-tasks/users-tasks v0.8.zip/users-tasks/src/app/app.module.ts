import { NgModule } from "@angular/core";
import { AppComponent } from "./app.component";
import { AppHeader } from "./app-header/app-header.component";
import { BrowserModule } from "@angular/platform-browser";
import { UsersModule } from "./app-users/users.module";
import { TasksModule } from "./tasks/tasks.module";

@NgModule({
    declarations: [AppComponent, AppHeader],
    bootstrap: [AppComponent],
    imports: [
        BrowserModule,
        UsersModule,
        TasksModule
    ]
})
export class AppModule{}
