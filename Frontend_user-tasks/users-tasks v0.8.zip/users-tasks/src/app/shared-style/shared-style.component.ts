import { Component } from '@angular/core';

@Component({
  selector: 'app-shared-style',
  templateUrl: './shared-style.component.html',
  styleUrl: './shared-style.component.css'
})
export class SharedStyleComponent {

}
