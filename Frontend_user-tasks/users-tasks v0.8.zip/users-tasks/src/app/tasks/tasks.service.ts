import { Injectable } from "@angular/core";
import { DUMMY_TASKS } from "./dummy_tasks";
import { ITask } from "./task.model";
import { IUser } from "../app-users/user.model";

@Injectable({ providedIn: 'root' })
export class TasksService{
    private tasks = DUMMY_TASKS;

    finishTask(id: number){
        for(let i=0; i<this.tasks.length; i++)
            if( this.tasks[i].id == id){
              this.tasks[i].completed = true;
              return;
            }
    }

    tasksByUser(user: IUser | undefined): ITask[] | undefined{
        if(user === undefined)
            return undefined;
      
          let filtered: ITask[] = [];
          for(let i=0; i<this.tasks.length; i++){
            if(this.tasks[i].userId === user.id){
              filtered.push(this.tasks[i]);
            }
          }
      
          return filtered;
    }

    saveNewTask(newTask: ITask){
        let max_id = this.tasks[0].id;
        for(let i=0; i<this.tasks.length; i++)
          if(this.tasks[i].id > max_id)
            max_id = this.tasks[i].id;
    
        max_id++;
        newTask.id = max_id;
        this.tasks.push(newTask);        
    }

}
