import { ITask } from "./task.model";

export const DUMMY_TASKS: ITask[] =[
    {
        id: 0,
        title: "TS alapok",
        date: new Date("2024-12-31"),
        description: "Megtanulni a TypeScript alapjait... Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi dolores doloribus culpa? At quae consequatur, culpa architecto quas tempora, aspernatur consectetur esse optio alias incidunt natus ipsum delectus. Vero, consectetur!",
        completed: false,
        userId: 2
    },
    {
        id: 1,
        title: "Elmosogatni",
        date: new Date("2024-11-06 20:00"),
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi dolores doloribus culpa? At quae consequatur, culpa architecto quas tempora, aspernatur consectetur esse optio alias incidunt natus ipsum delectus. Vero, consectetur!",
        completed: false,
        userId: 0
    },
    {
        id: 2,
        title: "Kutyakaja",
        date: new Date("2024-11-10 16:00"),
        description: "Vásárolni Buksinak kutyakaját a sarki kisboltlból. Pénteken korán bezár, ezért délután 4-ig el kell intézni!",
        completed: false,
        userId: 2
    },
    {
        id: 3,
        title: "Számitógép szerviz",
        date: new Date("2025-02-04"),
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi dolores doloribus culpa? At quae consequatur, culpa architecto quas tempora, aspernatur consectetur esse optio alias incidunt natus ipsum delectus. Vero, consectetur!",
        completed: false,
        userId: 3
    }
];