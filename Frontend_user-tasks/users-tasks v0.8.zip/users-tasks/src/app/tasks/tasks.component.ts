import { Component, inject, Input } from '@angular/core';
import { IUser } from '../app-users/user.model';
import { TasksService } from './tasks.service';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrl: './tasks.component.css'
})
export class TasksComponent {
  // @Input({ required: true }) name?: string;
  @Input({ required: true }) user?: IUser;
  @Input({ required: true }) selectedUserId?: number;
  tasksService: TasksService = inject(TasksService);
 
  isVisibleNewTaskComponent: boolean = false;

  get filteredTasks(){ return this.tasksService.tasksByUser(this.user); }

  VisibleNewTaskComponent(){ this.isVisibleNewTaskComponent = true; }

  HiddenNewTaskComponent(){ this.isVisibleNewTaskComponent = false; }

  onSaveNewTask(){ this.isVisibleNewTaskComponent = false; }
}
