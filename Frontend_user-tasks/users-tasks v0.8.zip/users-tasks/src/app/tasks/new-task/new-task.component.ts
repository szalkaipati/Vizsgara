import { Component, EventEmitter, Output, Input, inject } from '@angular/core';
import { DUMMY_USERS } from '../../app-users/dummy_users';
import { ITask } from '../task.model';
import { TasksService } from '../tasks.service';

@Component({
  selector: 'app-new-task',
  templateUrl: './new-task.component.html',
  styleUrl: './new-task.component.css'
})
export class NewTaskComponent {
  @Output() closeNewTaskComponent = new EventEmitter();
  @Output() sendNewTask = new EventEmitter();
  @Input({required: true}) userId!: number;
  taskService: TasksService = inject(TasksService);

  users = DUMMY_USERS;
  newTask: ITask = {
    id: -1,
    title: "",
    date: new Date(),
    description: "",
    completed: false,
    userId: 0
  };

  closingDialog(){ this.closeNewTaskComponent.emit(); }

  onSubmit(){
    this.newTask.userId = this.userId;
    this.taskService.saveNewTask(this.newTask);
    this.sendNewTask.emit();
  }

}
