export interface ITask{
    id: number,
    title: string,
    date: Date,
    description: string,
    completed: boolean,
    userId: number
};

