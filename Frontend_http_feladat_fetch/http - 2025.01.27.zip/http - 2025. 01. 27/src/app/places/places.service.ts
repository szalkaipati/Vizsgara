import { inject, Injectable, signal } from '@angular/core';

import { Place } from './place.model';
import { HttpClient } from '@angular/common/http';
import { catchError, pipe, tap, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class PlacesService {
  httpClient = inject(HttpClient);

  private userPlaces = signal<Place[]>([]);
  loadedUserPlaces = this.userPlaces.asReadonly();

  private places = signal<Place[] | undefined>([]);
  loadedPlaces = this.places.asReadonly();

  private server: string = 'http://localhost:3000/';
  error = signal<string | null>(null);
  isRequestInProgress = signal<boolean>(false);


  loadAvailablePlaces() {
    return this.httpClient
      .get<{places: Place[]}>(this.server+'places', {
        observe: 'response'
      })
      .pipe(
        tap({
          next: (response) => this.places.set(response.body!.places)
        }),        
        catchError( (error) => {          
          if(error.status == 500)
            this.error.set("There is some server error, please come back later...!");
          else if(error.status == 400)
            this.error.set("This is a not known page...")
          else
            this.error.set("This is an error, please come back later...!")
          
          return throwError(this.error());
        })  
      );
      
  }

  loadUserPlaces() {
    return this.httpClient.get<{places: Place[]}>(this.server+'user-places')
    .pipe(
      tap({
        next: (userPlaces) => this.userPlaces.set(userPlaces.places)
      })
    );
  }

  addPlaceToUserPlaces(place: Place) {
    const prevUserPlaces = this.userPlaces();
    if( !prevUserPlaces.some( i=> i.id == place.id) )
      this.userPlaces.update( prev => [...prev, place] );

    return this.httpClient.put(this.server+'user-places', {placeId: place.id})
      .pipe(
        catchError( (error)=>{
          this.userPlaces.set([...prevUserPlaces]);
          return error;
        })
      );
  }

  removeUserPlace(place: Place) {
    const prevUserPlaces = this.userPlaces();
    this.userPlaces.update( prev => prev.filter( i => i.id != place.id ) );

    return this.httpClient.delete(this.server+ 'user-places/' + place.id)
      .pipe(
        catchError( (error) =>{
          this.userPlaces.set([...prevUserPlaces]);
          return error;
        })
      );
  }
}
