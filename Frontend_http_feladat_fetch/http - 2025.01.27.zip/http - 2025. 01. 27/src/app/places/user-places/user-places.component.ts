import { Component, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { PlacesContainerComponent } from '../places-container/places-container.component';
import { PlacesComponent } from '../places.component';
import { Place } from '../place.model';
import { PlacesService } from '../places.service';

@Component({
  selector: 'app-user-places',
  standalone: true,
  templateUrl: './user-places.component.html',
  styleUrl: './user-places.component.css',
  imports: [PlacesContainerComponent, PlacesComponent],
})
export class UserPlacesComponent implements OnInit {
  destroyRef = inject(DestroyRef);
  placesService = inject(PlacesService);

  userPlaces = this.placesService.loadedUserPlaces;
  error = signal<string | null>(null);

  ngOnInit(): void {
    const subscription = this.placesService.loadUserPlaces()
      .subscribe({        
        error: (error) =>{
          this.error.set("There is some error. Please try again later!");
        }
      });

      this.destroyRef.onDestroy( ()=>{
        subscription.unsubscribe();
      });
  }

  onPlaceDelete(place: Place){
    const subscription = this.placesService.removeUserPlace(place)
      .subscribe({
        error: (error)=>{
          console.log(error.message);
        }
      });

      this.destroyRef.onDestroy( ()=>{
        subscription.unsubscribe();
      });
  }
}
