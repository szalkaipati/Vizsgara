import { Component, inject } from '@angular/core';
import { ErrorHandlingComponent } from './error-handling/error-handling.component';
import { AvailablePlacesComponent } from './places/available-places/available-places.component';
import { UserPlacesComponent } from './places/user-places/user-places.component';
import { PlacesService } from './places/places.service';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  imports: [AvailablePlacesComponent, UserPlacesComponent, ErrorHandlingComponent],
})
export class AppComponent {
  placeService = inject(PlacesService);
}
