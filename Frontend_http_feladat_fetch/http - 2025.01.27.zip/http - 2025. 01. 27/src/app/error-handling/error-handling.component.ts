import { Component, inject } from '@angular/core';
import { PlacesService } from '.././places/places.service';

@Component({
  selector: 'app-error-handling',
  standalone: true,
  imports: [],
  templateUrl: './error-handling.component.html',
  styleUrl: './error-handling.component.css'
})
export class ErrorHandlingComponent {
  placesService = inject(PlacesService);
  error = this.placesService.error;

  onClickOk(){
    this.error.set(null);
  }
}
