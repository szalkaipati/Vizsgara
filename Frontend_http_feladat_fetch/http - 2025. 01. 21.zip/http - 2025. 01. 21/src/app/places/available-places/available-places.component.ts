import { Component, DestroyRef, inject, OnInit, signal } from '@angular/core';

import { Place } from '../place.model';
import { PlacesComponent } from '../places.component';
import { PlacesContainerComponent } from '../places-container/places-container.component';
import { PlacesService } from '../places.service';

@Component({
  selector: 'app-available-places',
  standalone: true,
  templateUrl: './available-places.component.html',
  styleUrl: './available-places.component.css',
  imports: [PlacesComponent, PlacesContainerComponent]
})
export class AvailablePlacesComponent implements OnInit {
  destroy = inject(DestroyRef);
  placesService = inject(PlacesService);

  places = signal<Place[] | undefined>(undefined);
  isRequestInProgress = signal(false);
  error = signal<string | null>(null);

  ngOnInit() {
    this.isRequestInProgress.set(true);
    const subscripton = this.placesService.loadAvailablePlaces()
      .subscribe({
        next: (responsonse) => {
          this.places.set(responsonse.body?.places);
        },
        error: (error) =>{
          console.log(error);
        },
        complete: () =>{
          this.isRequestInProgress.set(false);
        }
      });

      this.destroy.onDestroy( ()=>{
        subscripton.unsubscribe();
      });
  }

  onSelectPlace(place: Place){
    const subscription = this.placesService.addPlaceToUserPlaces(place)
      .subscribe();

      this.destroy.onDestroy( ()=>{
        subscription.unsubscribe();
      })
  }

}
