import { Component, DestroyRef, inject, OnInit, signal } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Place } from '../place.model';
import { PlacesComponent } from '../places.component';
import { PlacesContainerComponent } from '../places-container/places-container.component';

@Component({
  selector: 'app-available-places',
  standalone: true,
  templateUrl: './available-places.component.html',
  styleUrl: './available-places.component.css',
  imports: [PlacesComponent, PlacesContainerComponent]
})
export class AvailablePlacesComponent implements OnInit {
  places = signal<Place[] | undefined>(undefined);
  httpClient = inject(HttpClient);
  destroy = inject(DestroyRef);
  isRequestInProgress = signal(false);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.isRequestInProgress.set(true);
    const subscripton = this.httpClient
      .get<{places: Place[]}>('http://localhost:3000/places', {
        observe: 'response'
      })
      .subscribe({
        next: (responsonse) => {
          // console.log(responsonse);
          // console.log(responsonse.body?.places);
          this.places.set(responsonse.body?.places);
        },
        error: (error) =>{
          console.log(error.message);
          if(error.status == 500)
            this.error.set("There is some server error, please come back later...!");
          else if(error.status == 400)
            this.error.set("This is a not known page...")
          else
            this.error.set("This is an error, please come back later...!")
        },
        complete: () =>{
          this.isRequestInProgress.set(false);
        }
      });

      this.destroy.onDestroy( ()=>{
        subscripton.unsubscribe();
      });
  }

  onSelectPlace(place: Place){
    const subscription = this.httpClient.put('http://localhost:3000/user-places', {placeId: place.id})
      .subscribe({
        next: (response)=>{
          console.log(response);
        }
      });

      this.destroy.onDestroy( ()=>{
        subscription.unsubscribe();
      })
  }

}
