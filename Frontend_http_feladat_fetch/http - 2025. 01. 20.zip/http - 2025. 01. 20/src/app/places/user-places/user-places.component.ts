import { Component, inject, OnInit, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { PlacesContainerComponent } from '../places-container/places-container.component';
import { PlacesComponent } from '../places.component';
import { Place } from '../place.model';

@Component({
  selector: 'app-user-places',
  standalone: true,
  templateUrl: './user-places.component.html',
  styleUrl: './user-places.component.css',
  imports: [PlacesContainerComponent, PlacesComponent],
})
export class UserPlacesComponent implements OnInit {
  userPlaces = signal<Place[] | undefined>(undefined);
  httpClient = inject(HttpClient);
  error = signal<string | null>(null);

  ngOnInit(): void {
    const subscription = this.httpClient.get<{places: Place[]}>('http://localhost:3000/user-places')
      .subscribe({
        next: (data)=>{
          // console.log(data);
          this.userPlaces.set(data.places);          
        },
        error: (error) =>{
          this.error.set("There is some error. Please try again later!");
        }
      });
  }
}
