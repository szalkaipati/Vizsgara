import { Component } from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

function postalCodeValidator(control: AbstractControl) {
  let num = parseInt(control.value);
  if (control.value.length == 4 && Number.isInteger(num)) return null;

  return { invalidPostalCode: true };
}

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css',
})
export class SignupComponent {
  myForm = new FormGroup({
    email: new FormControl('', {
      validators: [Validators.required, Validators.email],
    }),
    passwords: new FormGroup({
      password: new FormControl(''),
      confirmPassword: new FormControl(''),
    }),
    name: new FormGroup({
      firstName: new FormControl(''),
      lastName: new FormControl(''),
    }),
    address: new FormGroup({
      street: new FormControl(''),
      number: new FormControl(''),
      postalCode: new FormControl('', {
        validators: [postalCodeValidator],
      }),
      city: new FormControl(''),
    }),
    role: new FormControl<
      'student' | 'teacher' | 'employee' | 'founder' | 'other'
    >('student'),
    source: new FormArray([
      new FormControl(false),
      new FormControl(false),
      new FormControl(false),
    ]),
    terms: new FormControl(false, {
      validators: [Validators.requiredTrue],
    }),
  });

  get postalCodeInvalid() {
    const pc = this.myForm.controls.address.controls.postalCode;
    return pc.touched && pc.dirty && pc.invalid;
  }

  onSubmit() {
    console.log(this.myForm);
  }
}
