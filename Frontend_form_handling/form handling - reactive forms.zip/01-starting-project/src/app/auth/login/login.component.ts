import { Component, DestroyRef, inject, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { debounceTime, of } from 'rxjs';

// custom validator
function mustContainQuestionMark(control: AbstractControl) {
  if (control.value.includes('?')) return null;

  return { doesNotContainQuestionMark: true };
}

// unique e-mail: 'bolyai-szakkozep.hu'
// Observable-t kell visszaadnia
function emailIsUnique(control: AbstractControl) {
  if (control.value.includes('bolyai-szakkozep.hu')) return of(null);

  return of({ notUniqueEmail: true });
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent implements OnInit {
  destroyRef = inject(DestroyRef);

  myForm = new FormGroup({
    email: new FormControl('', {
      validators: [Validators.required, Validators.email],
      asyncValidators: [emailIsUnique],
    }),
    password: new FormControl('', {
      validators: [
        Validators.required,
        Validators.minLength(6),
        mustContainQuestionMark,
      ],
    }),
  });

  ngOnInit(): void {
    const savedEmail = window.localStorage.getItem('saved-email');
    if(savedEmail){
      const loadedEmail = JSON.parse(savedEmail);
      this.myForm.patchValue({
        email: loadedEmail.email
      });
    }

    const subscription = this.myForm.valueChanges
      .pipe(debounceTime(500))
      .subscribe({
        next: (value) => {
          // console.log(value);
          if(this.myForm.controls.email.valid){
            window.localStorage.setItem(
              'saved-email',
              JSON.stringify({email: value.email})
            );
          }
        },
      });

    this.destroyRef.onDestroy(() => {
      subscription.unsubscribe();
    });
  }

  get emailInvalid() {
    return (
      this.myForm.controls.email.touched &&
      this.myForm.controls.email.dirty &&
      this.myForm.controls.email.invalid
    );
  }

  get passwordInvalid() {
    return (
      this.myForm.controls.password.touched &&
      this.myForm.controls.password.dirty &&
      this.myForm.controls.password.invalid
    );
  }

  onSubmit() {
    console.log(this.myForm);

    // ha invalid a form, akkor nem "küldjük el"
    if (this.myForm.invalid) return;

    // ide jönne a többi kód, pl. API hívás, stb.
  }
}
