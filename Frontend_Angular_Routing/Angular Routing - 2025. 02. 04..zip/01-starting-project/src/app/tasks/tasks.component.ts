import { Component, computed, inject, input, OnChanges, OnInit, SimpleChanges } from '@angular/core';

import { TaskComponent } from './task/task.component';
import { Task } from './task/task.model';
import { TasksService } from './tasks.service';

@Component({
  selector: 'app-tasks',
  standalone: true,
  templateUrl: './tasks.component.html',
  styleUrl: './tasks.component.css',
  imports: [TaskComponent],
})
export class TasksComponent {
  private tasksService = inject(TasksService);
  userId = input.required<string>();
  userTasks = computed( () => this.tasksService.tasksByUserId(this.userId()) );

}
/*
export class TasksComponent implements OnInit, OnChanges {
  private tasksService = inject(TasksService);
  userId = input.required<string>();
  userTasks: Task[] = [];

  ngOnInit(): void {
    this.userTasks = this.tasksService.tasksByUserId(this.userId());
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.userTasks = this.tasksService.tasksByUserId(this.userId());
  }
}
*/
