import { Routes } from "@angular/router";

import { NotFoundComponent } from "./app/not-found/not-found.component";
import { NewTaskComponent } from "./app/tasks/new-task/new-task.component";
import { NoTaskComponent } from "./app/tasks/no-task/no-task.component";
import { TasksComponent } from "./app/tasks/tasks.component";
import { UserTasksComponent } from "./app/users/user-tasks/user-tasks.component";

export const routes: Routes = [
    {
        path: '',
        component: NoTaskComponent,
    },
    {
        path: 'users/:userId',      // <domain>/users/u2
        component: UserTasksComponent,
        children: [
            {
                path: '',
                redirectTo: 'tasks',
                pathMatch: 'full'
            },
            {
                path: 'tasks',      // <domain>/users/u2/tasks
                component: TasksComponent
            },
            {
                path: 'tasks/new',
                component: NewTaskComponent
            }
        ]
    },
    {
        path: '**',     // semelyik előző url sem
        component: NotFoundComponent
    } 
]