import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { DataSenderService } from '../datasender.service';

@Component({
  selector: 'app-receiver',
  imports: [],
  templateUrl: './receiver.component.html',
  styleUrl: './receiver.component.css',
})
export class ReceiverComponent implements OnInit, OnDestroy {
  receivedMessage: string = '';
  private subscription: Subscription = new Subscription();
  dataSendingService = inject(DataSenderService);

  ngOnInit(): void {
    this.subscription = this.dataSendingService.messageObservable$.subscribe( message => {
      this.receivedMessage = message;
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
