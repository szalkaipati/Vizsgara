import { Component, inject, OnInit } from '@angular/core';
import { DataSenderService } from '../datasender.service';

@Component({
  selector: 'app-receiver',
  imports: [],
  templateUrl: './receiver.component.html',
  styleUrl: './receiver.component.css'
})
export class ReceiverComponent implements OnInit {
  message: string = "";
  dataSenderService = inject(DataSenderService);

  // nem kell feliratkozni a signalra!!!!!!
  ngOnInit(): void {
    this.message = this.dataSenderService.Message;
  }
}
