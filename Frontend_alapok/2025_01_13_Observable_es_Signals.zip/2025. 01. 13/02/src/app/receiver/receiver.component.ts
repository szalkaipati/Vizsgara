import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { DataSenderService } from '../datasender.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-receiver',
  imports: [],
  templateUrl: './receiver.component.html',
  styleUrl: './receiver.component.css'
})
export class ReceiverComponent implements OnInit, OnDestroy {
  dataSenderService = inject(DataSenderService);
  subscription: Subscription = new Subscription();
  message: string = "";

  ngOnInit(): void {
    this.subscription = this.dataSenderService.currentMessage$.subscribe( message => {
      this.message = message;
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();    
  }

}
