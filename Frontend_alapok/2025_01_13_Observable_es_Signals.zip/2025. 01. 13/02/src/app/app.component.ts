import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ReceiverComponent } from "./receiver/receiver.component";
import { SenderComponent } from "./sender/sender.component";

@Component({
  selector: 'app-root',
  imports: [ReceiverComponent, SenderComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {  
}
