import { Component, inject } from '@angular/core';
import { DataSenderService } from '../datasender.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-sender',
  imports: [FormsModule],
  templateUrl: './sender.component.html',
  styleUrl: './sender.component.css'
})
export class SenderComponent {
  dataSenderService = inject(DataSenderService);
  message: string = ""

  submitMessage(){
    this.dataSenderService.updateMessage(this.message);
    this.message = "";
  }
}
