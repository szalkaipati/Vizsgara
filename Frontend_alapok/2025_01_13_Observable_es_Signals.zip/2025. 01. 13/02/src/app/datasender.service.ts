import { Injectable } from "@angular/core";
import { BehaviorSubject, map } from "rxjs";


@Injectable({
    providedIn: 'root'
})
export class DataSenderService{
    private message = new BehaviorSubject("Hello World!");    
    currentMessage$ = this.message.asObservable().pipe( map( m => m+" !!!") );

    updateMessage(message: string){
        this.message.next(message);
    }

}