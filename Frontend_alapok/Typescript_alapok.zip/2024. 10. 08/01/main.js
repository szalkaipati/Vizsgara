console.log("Hurrá!");
// statikus típusosság
var szoveg = "Hello World!";
var szoveg2 = "Csókolom!";
// szoveg2 = 3;     // ez hibát okoz
// függvények
function koszon(nev) {
    console.log("J\u00F3 napot k\u00EDv\u00E1nok ".concat(nev, "!"));
}
koszon("Józsi");
var koszon2 = function (nev) {
    console.log("J\u00F3 est\u00E9t k\u00EDv\u00E1nok ".concat(nev, "!"));
};
koszon2("Béla");
var elkoszon = function (nev) { return "Viszontl\u00E1t\u00E1sra ".concat(nev, "!"); };
console.log(elkoszon("Rebeka"));
var osszead = function (a, b) { return a + b; };
console.log(osszead(13.67, 22.5));
// Beépített DOM interfészek
document.querySelector('h1');
document.querySelector('.bekezdes');
// document.querySelector(13);      // fordítási időben hiba
