console.log("Hurrá!");

// statikus típusosság
let szoveg: string = "Hello World!";
let szoveg2 = "Csókolom!";
// szoveg2 = 3;     // ez hibát okoz


// függvények
function koszon(nev){
    console.log(`Jó napot kívánok ${nev}!`);
}
koszon("Józsi");

let koszon2 = function(nev){
    console.log(`Jó estét kívánok ${nev}!`);
}
koszon2("Béla");

let elkoszon = nev => `Viszontlátásra ${nev}!`;
console.log(elkoszon("Rebeka"));

let osszead = (a, b) => { return a+b; };
console.log(osszead(13.67, 22.5));

// Beépített DOM interfészek
document.querySelector('h1');
document.querySelector('.bekezdes');
// document.querySelector(13);      // fordítási időben hiba