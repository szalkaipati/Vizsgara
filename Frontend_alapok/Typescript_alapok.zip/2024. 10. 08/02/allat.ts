export class Allat{
    private nev: string;
    eletkor: number;

    constructor(_nev: string, _kor: number){
        this.nev = _nev;
        this.eletkor = _kor;
    }

    hogyHivjak(){
        console.log(`Az állat neve: ${this.nev}`);
    }

    mikorSzuletett(){
        return (new Date().getFullYear()-this.eletkor);
    }

}