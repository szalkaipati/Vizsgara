import { Allat } from "./allat";

let kutya = new Allat("Bodri", 8);
kutya.hogyHivjak();
console.log(`Születési év: ${kutya.mikorSzuletett()}`);