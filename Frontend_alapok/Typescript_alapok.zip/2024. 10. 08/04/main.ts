// a.) Interface
interface IDolgozo{
    nev: string;
    varos: string;
}

let bela: IDolgozo;
bela = {
    nev: "Kováts Béla",
    varos: "Esztergom"
};

function dolgozokAdatai(d: IDolgozo){
    console.log(`Dolgozó neve: ${d.nev}, lakhelye: ${d.varos}`);
}

// 'elvont' függvénnyel (más nyelvekben: virtuális függvény)
interface negativE{
    (szam: number): boolean;
}

let szamol: negativE = function(szam: number):boolean{
    return szam < 0;
}

// interface lehet egy leendő osztálynak prototípusa is
class Dolgozo implements IDolgozo{
    nev: string;
    varos: string;

    constructor(_nev: string, _varos: string){
        this.nev = _nev;
        this.varos = _varos;
    }
}

// b.) Osztályok + öröklés
class Allat{
    protected hang: string;
    
    constructor(){
        this.hang = '';
    }

    fut(){
        console.log(`Az állat fut.`);
    }
    hangotAd(): void{
        console.log(`Az állat hangot ad ki: ${this.hang}`);
    }
}

class Kutya extends Allat{
    hangotAd(): void {
        this.hang = 'ugat';
        super.hangotAd();
    }
}

let rexi: Kutya = new Kutya();
rexi.fut();
rexi.hangotAd();

/*
Házi feladat:
Adatrejtés: public, private, protected
- get(), set()

Generikus tagok TS-ben

`Factory` tervezés minta
*/