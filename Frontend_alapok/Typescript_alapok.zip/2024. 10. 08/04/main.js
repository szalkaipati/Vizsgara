var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var bela;
bela = {
    nev: "Kováts Béla",
    varos: "Esztergom"
};
function dolgozokAdatai(d) {
    console.log("Dolgoz\u00F3 neve: ".concat(d.nev, ", lakhelye: ").concat(d.varos));
}
var szamol = function (szam) {
    return szam < 0;
};
// interface lehet egy leendő osztálynak prototípusa is
var Dolgozo = /** @class */ (function () {
    function Dolgozo(_nev, _varos) {
        this.nev = _nev;
        this.varos = _varos;
    }
    return Dolgozo;
}());
// b.) Osztályok + öröklés
var Allat = /** @class */ (function () {
    function Allat() {
        this.hang = '';
    }
    Allat.prototype.fut = function () {
        console.log("Az \u00E1llat fut.");
    };
    Allat.prototype.hangotAd = function () {
        console.log("Az \u00E1llat hangot ad ki: ".concat(this.hang));
    };
    return Allat;
}());
var Kutya = /** @class */ (function (_super) {
    __extends(Kutya, _super);
    function Kutya() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Kutya.prototype.hangotAd = function () {
        this.hang = 'ugat';
        _super.prototype.hangotAd.call(this);
    };
    return Kutya;
}(Allat));
var rexi = new Kutya();
rexi.fut();
rexi.hangotAd();
/*
Házi feladat:
Adatrejtés: public, private, protected
- get(), set()

Generikus tagok TS-ben

`Factory` tervezés minta
*/ 
