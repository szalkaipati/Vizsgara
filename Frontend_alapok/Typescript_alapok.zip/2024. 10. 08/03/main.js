// a.) Típusok
var logikai = true;
logikai = false;
var szam = 6;
var hexaSzam = 0xcf;
var binSzam = 747;
var nagySzam = 9999999999999n; // ES2020-tól felfelé
var szoveg = "Ez egy szöveg";
// String interpoláció
var szoveg2 = "A kedvenc sz\u00E1mom: ".concat(binSzam);
var barmi = 12;
barmi = "kiskutya";
var ismeretlen;
var u = undefined;
var n = null;
// b.) Kasztolás, típuskonverzió
var ize = 12;
ize = "Ez egy szöveg!";
// ize.substring(1, 2);
ize.substring(0, 6);
ize.substring(0, 6);
// c.) Tömbök
var tomb = ['alma', 'körte', 'barack'];
var tomb2 = ['Audi', 'BMW', 'Citruen', 'Dacia'];
// d.) Tupple (rendezett N-es)
var udvar; // rendezett 3-as
udvar = ['liba', 12, true];
udvar[0].substring(0, 2);
// udvar[1].substring(0, 2);           // nem működik
// e.) Enum (felsorlás típus)
var Etelek;
(function (Etelek) {
    Etelek[Etelek["h\u00FAsleves"] = 0] = "h\u00FAsleves";
    Etelek[Etelek["p\u00F6rk\u00F6lt"] = 1] = "p\u00F6rk\u00F6lt";
    Etelek[Etelek["guly\u00E1s"] = 5] = "guly\u00E1s";
    Etelek[Etelek["fagyi"] = 6] = "fagyi";
    Etelek[Etelek["sal\u00E1ta"] = 7] = "sal\u00E1ta";
})(Etelek || (Etelek = {}));
;
var etel = Etelek.gulyás;
console.log(etel);
var Szinek;
(function (Szinek) {
    Szinek[Szinek["piros"] = 16711680] = "piros";
    Szinek[Szinek["z\u00F6ld"] = 65280] = "z\u00F6ld";
    Szinek[Szinek["k\u00E9k"] = 255] = "k\u00E9k";
    Szinek[Szinek["kedvenc"] = 11272447] = "kedvenc";
})(Szinek || (Szinek = {}));
;
var vanKutyam = 'igaz';
var sz = 3;
// let sz: kedvencSzamok = 12;
