// a.) Típusok
let logikai: boolean = true;
logikai = false;

let szam: number = 6;
let hexaSzam: number = 0xcf;
let binSzam: number = 0b1011101011;

let nagySzam: bigint = 9999999999999n;      // ES2020-tól felfelé

let szoveg: string = "Ez egy szöveg";
// String interpoláció
let szoveg2: string = `A kedvenc számom: ${binSzam}`;

let barmi: any = 12;
barmi = "kiskutya";
let ismeretlen: unknown;

let u: undefined = undefined;
let n: null = null;

// b.) Kasztolás, típuskonverzió
let ize: any = 12;
ize = "Ez egy szöveg!";
// ize.substring(1, 2);
(ize as string).substring(0, 6);
(<string>ize).substring(0, 6);

// c.) Tömbök
let tomb: string[] = ['alma', 'körte', 'barack'];
let tomb2: Array<string> = ['Audi', 'BMW', 'Citruen', 'Dacia'];

// d.) Tupple (rendezett N-es)
let udvar: [string, number, boolean];       // rendezett 3-as
udvar = ['liba', 12, true];
udvar[0].substring(0, 2);
// udvar[1].substring(0, 2);           // nem működik

// e.) Enum (felsorlás típus)
enum Etelek{
    húsleves,
    pörkölt,
    gulyás = 5,
    fagyi,
    saláta
};

let etel: Etelek = Etelek.gulyás;
console.log(etel);

enum Szinek{
    piros = 0xff0000,
    zöld = 0x00ff00,
    kék = 0x0000ff,
    kedvenc = 0xac00ff
};

// f.) Literál típus (saját)
type ih = 'igaz' | 'hamis';
let vanKutyam: ih = 'igaz';
// let vanCicamm: ih = 'talán';         // hiba

type kedvencSzamok = 2 | 3 | 5 | 7 | 11 | 13 | 17 | 19;
let sz: kedvencSzamok = 3;
// let sz: kedvencSzamok = 12;