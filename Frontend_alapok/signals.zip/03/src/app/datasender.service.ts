import { Injectable, signal, computed } from "@angular/core";


@Injectable({
    providedIn: 'root'
})
export class DataSenderService{
    private message = signal<string>("Hello World!");
    messageSender = computed( () => this.message()+"  !!!" );

    updateMessage(message: string){
        this.message.set(message);
    }

    get Message(): string{
        return this.messageSender();
    }
}