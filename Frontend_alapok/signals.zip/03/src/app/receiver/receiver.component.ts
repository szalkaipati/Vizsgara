import { Component, effect, EffectRef, inject, OnDestroy, OnInit } from '@angular/core';
import { DataSenderService } from '../datasender.service';

@Component({
  selector: 'app-receiver',
  imports: [],
  templateUrl: './receiver.component.html',
  styleUrl: './receiver.component.css'
})
export class ReceiverComponent implements OnDestroy {
  message: string = "";
  dataSenderService = inject(DataSenderService);
  effectRef: EffectRef = effect( ()=> {} );

  // nem kell feliratkozni a signalra!!!!!!
  constructor(){
    this.effectRef = effect( () => {
      this.message = this.dataSenderService.Message;
    } );
  }

  ngOnDestroy(): void {
    this.effectRef.destroy();
  }
}
