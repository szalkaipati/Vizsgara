import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DataSenderService } from '../datasender.service';

@Component({
  selector: 'app-sender',
  imports: [FormsModule],
  templateUrl: './sender.component.html',
  styleUrl: './sender.component.css'
})
export class SenderComponent {
  message: string = "";
  dataSenderService = inject(DataSenderService);

  submitMessage(){
    this.dataSenderService.updateMessage(this.message);
    this.message = "";
  }  

}
