﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using MySql.Data.MySqlClient;
using Mysqlx.Session;
using MySqlX.XDevAPI.Common;

namespace CegesParkolohaz1
{
    internal class DatabaseConnection
    {
        private MySqlConnection conn;

        public DatabaseConnection(string connStr)
        {
            conn = new MySqlConnection(connStr);
        }

        public void OpenConnection()
        {
            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba a kapcsolódás során: {ex.Message}");
            }
        }

        public void CloseConnection() 
        {
            if (conn.State == System.Data.ConnectionState.Open)
            {
                conn.Close();
            }
        }

        public List<string> GetEmployees()
        {
            List<string> results = new List<string>();
            string query = "SELECT nev FROM alkalmazottak;";

            try
            {
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        results.Add(reader[0].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SQL-lekérdezési hiba: {ex.Message}");
            }
            return results;
        }

        public List<Rental> GetEmployeeRentals(string employee)
        {
            string employeeId = "";
            string query = $"SELECT azon FROM alkalmazottak WHERE nev = '{employee}';";
            try
            {
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using(MySqlDataReader reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    employeeId = reader[0].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SQL-lekérdezési hiba: {ex.Message}");
            }
            
            List<Rental> rentals = new List<Rental>();
            query = $"SELECT autoAzon, datum, kmAllas, bekiHajtas FROM parkolo WHERE alkalmazottAzon = '{employeeId}'";
            string direction = "";
            try
            {
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        if (Convert.ToInt32(reader[3]) == 0)
                        {
                            direction = "ki";
                        }
                        else
                        {
                            direction = "be";
                        }
                        Rental rental = new Rental(Convert.ToInt32(reader[0]), reader[1].ToString(), "rendszam", "tipus", Convert.ToInt32(reader[2]), direction);
                        rentals.Add(rental);

                    }
                }
                foreach(var rental in rentals)
                {
                    rental.CarLicensePlate = GetCarLicensePlate(rental.CarId);
                    rental.CarType = GetCarType(rental.CarId);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SQL-lekérdezési hiba: {ex.Message}");
            }
            return rentals;

        }

        public string GetCarLicensePlate(int carId)
        {
            string carLicensePlate = "";
            string query = $"SELECT rendszam FROM autok WHERE azon = '{carId}';";
            try
            {
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    carLicensePlate = reader[0].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SQL-lekérdezési hiba: {ex.Message}");
            }
            return carLicensePlate;
        }

        public string GetCarType(int carId)
        {
            string carType = "";
            string query = $"SELECT tipus FROM autok WHERE azon = '{carId}';";
            try
            {
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    carType = reader[0].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SQL-lekérdezési hiba: {ex.Message}");
            }
            return carType;
        }

        public List<string> GetCars()
        {
            List<string> result = new List<string>();
            string query = "SELECT rendszam FROM autok;";
            try
            {
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(reader[0].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SQL-lekérdezési hiba: {ex.Message}");
            }
            return result;
        }

        public void NewRentalSave(string name, string car, string date, string time, int km, int inOut)
        {
            date = date.Replace(". ", "-");
            date = date.Remove(date.Length - 1);
            date = "'" + date + " " + time + "'";
            string query = $"INSERT INTO parkolo (datum, autoAzon, alkalmazottAzon, kmAllas, bekiHajtas) VALUE ({date}, {GetCarId(car)}, {GetEmployeeId(name)}, {km}, {inOut});";
            try
            {
                using(MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SQL-lekérdezési hiba: {ex.Message}");
            }
        }

        public int GetEmployeeId(string employeeName)
        {
            int employeeid = 0;
            string query = $"SELECT azon FROM alkalmazottak WHERE nev = '{employeeName}'";
            try
            {
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    employeeid = Convert.ToInt32(reader[0]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SQL-lekérdezési hiba: {ex.Message}");
            }
            return employeeid;
        }

        public int GetCarId(string carLicensePlate)
        {
            int carid = 0;
            string query = $"SELECT azon FROM autok WHERE rendszam = '{carLicensePlate}'";
            try
            {
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    carid = Convert.ToInt32(reader[0]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SQL-lekérdezési hiba: {ex.Message}");
            }
            return carid;
        }
    }
}
