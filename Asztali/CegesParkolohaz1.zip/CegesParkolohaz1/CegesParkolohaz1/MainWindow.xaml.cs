﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CegesParkolohaz1
{
   
    public partial class MainWindow : Window
    {
        DatabaseConnection dbConn;
        public MainWindow()
        {
            InitializeComponent();

            string connStr = "Server=localhost;Database=parkolohaz;User ID=root;";
            dbConn = new DatabaseConnection(connStr);
            try
            {
                dbConn.OpenConnection();

                var employees = dbConn.GetEmployees();
                EmployeeListBox.ItemsSource = employees;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba történt a kapcsolódás során: {ex.Message}");
            }
            
        }

        private void EmployeeListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var rentals = dbConn.GetEmployeeRentals(EmployeeListBox.SelectedItem.ToString());
            EmployeeTable.ItemsSource = rentals;

            EmployeeName.Text = EmployeeListBox.SelectedItem.ToString() + " bérlései:";
            EmployeeName.Visibility = Visibility.Visible;

            if (rentals.Count == 0)
            {
                NoRentalsMessage.Visibility = Visibility.Visible;
            }
            else
            {
                NoRentalsMessage.Visibility = Visibility.Collapsed;
            }
        }

        private void OpenNewRentalWindow(object sender, RoutedEventArgs e)
        {
            NewRentalWindow newRentalWindow = new NewRentalWindow();
            newRentalWindow.Show();
        }

        protected override void OnClosed(EventArgs e)
        {
            dbConn.CloseConnection();
            base.OnClosed(e);
        }
    }
}