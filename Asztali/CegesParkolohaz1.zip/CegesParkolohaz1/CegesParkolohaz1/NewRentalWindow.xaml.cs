﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CegesParkolohaz1
{
    /// <summary>
    /// Interaction logic for NewRentalWindow.xaml
    /// </summary>
    public partial class NewRentalWindow : Window
    {
        DatabaseConnection dbConn;
        public NewRentalWindow()
        {
            InitializeComponent();

            string connStr = "Server=localhost;Database=parkolohaz;User ID=root;";
            dbConn = new DatabaseConnection(connStr);
            try
            {
                dbConn.OpenConnection();

                var employees = dbConn.GetEmployees();
                cmbName.ItemsSource = employees;
                cmbName.SelectedIndex = 0;

                var cars = dbConn.GetCars();
                cmbCar.ItemsSource = cars;
                cmbCar.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba történt a kapcsolódás során: {ex.Message}");
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (dpRentalDate.SelectedDate == null) 
            {
                MessageBox.Show("Kérem válasszon ki egy dátumot!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Warning);
                dpRentalDate.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(tbRentalTime.Text))
            {
                MessageBox.Show("Kérem adjon meg egy időpontot!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Warning);
                tbRentalTime.Focus();
                return;
            }

            if(!Regex.IsMatch(tbRentalTime.Text, @"^([01]?\d|2[0-3]):([0-5]?\d):([0-5]?\d)$"))
            {
                MessageBox.Show("Kérem adjon meg érvényes időpontot (óó:pp:mm formátumban)!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Warning);
                tbRentalTime.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(tbKm.Text))
            {
                MessageBox.Show("Kérem adjon meg egy km óra állást!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Warning);
                tbKm.Focus();
                return;
            }

            if (!int.TryParse(tbKm.Text, out int kmOraAllas) || kmOraAllas <= 0)
            {
                MessageBox.Show("A km óra állásnak pozitív egész számnak kell lennie!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Warning);
                tbKm.Focus();
                return;
            }
            dbConn.NewRentalSave(cmbName.Text, cmbCar.Text, dpRentalDate.Text, tbRentalTime.Text, Convert.ToInt32(tbKm.Text), Convert.ToInt32(rbIn.IsChecked));
            this.Close();

        }
    }
}
