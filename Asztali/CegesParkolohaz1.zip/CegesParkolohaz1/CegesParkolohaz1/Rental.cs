﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CegesParkolohaz1
{
    class Rental
    {
        public int CarId { get; set; }
        public string Date {  get; set; }
        public string CarLicensePlate { get; set; }
        public string CarType { get; set; }
        public int Odometer { get; set; }
        public string Direction { get; set; }

        public Rental(int carId, string date, string carLicensePlate, string carType, int odometer, string direction)
        {
            CarId = carId;
            Date = date;
            CarLicensePlate = carLicensePlate;
            CarType = carType;
            Odometer = odometer;
            Direction = direction;
        }

    }
}
